## 中文序列标注相关数据集

包含原始训练，预测数据和数据处理脚本。以及已经支持的模型在测试集预测的pkl文件，支持直接用evaluation.py评估该模型在测试集效果

1. NER-MSRA
2. NER-People Daily
3. CWS-MSR
