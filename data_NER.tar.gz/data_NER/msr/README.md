## Chinese Word Segmentation Dataset - MSR 

中文分词任务

1. 原始数据包括以.utf8结尾的文件
2. 运行python ./data/msr/preprocess.py 生成tfrecord和data_params数据


**Reference**:   
<http://sighan.cs.uchicago.edu/bakeoff2005/>